/*******************************************************************************
* File Name: cycfg_routing.h
*
* Description:
* Establishes all necessary connections between hardware elements.
* This file was automatically generated and should not be modified.
* Tools Package 2.4.0.5972
* mtb-pdl-cat1 2.4.0.14850
* personalities 6.0.0.0
* udd 3.0.0.2024
*
********************************************************************************
* Copyright 2022 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#if !defined(CYCFG_ROUTING_H)
#define CYCFG_ROUTING_H

#if defined(__cplusplus)
extern "C" {
#endif

#include "cycfg_notices.h"
void init_cycfg_routing(void);
#define init_cycfg_connectivity() init_cycfg_routing()
#define ioss_0_port_0_pin_0_ANALOG P0_0_SRSS_WCO_IN
#define ioss_0_port_0_pin_1_ANALOG P0_1_SRSS_WCO_OUT
#define ioss_0_port_6_pin_4_HSIOM P6_4_PERI_TR_IO_INPUT12
#define ioss_0_port_6_pin_5_HSIOM P6_5_PERI_TR_IO_INPUT13
#define ioss_0_port_6_pin_6_HSIOM P6_6_CPUSS_SWJ_SWDIO_TMS
#define ioss_0_port_6_pin_7_HSIOM P6_7_CPUSS_SWJ_SWCLK_TCLK
#define ioss_0_port_9_pin_4_HSIOM P9_4_TCPWM1_LINE0
#define ioss_0_port_9_pin_6_HSIOM P9_6_TCPWM0_LINE0

#define CYBSP_I2C_SCL_digital_in_0_TRIGGER_IN_0 TRIG12_IN_PERI_TR_IO_INPUT12
#define CYBSP_I2C_SCL_digital_in_0_TRIGGER_IN_1 TRIG3_IN_TR_GROUP12_OUTPUT6
#define CYBSP_I2C_SDA_digital_in_0_TRIGGER_IN_0 TRIG12_IN_PERI_TR_IO_INPUT13
#define CYBSP_I2C_SDA_digital_in_0_TRIGGER_IN_1 TRIG3_IN_TR_GROUP12_OUTPUT7
#define tcpwm_1_cnt_2_count_0_TRIGGER_OUT TRIG3_OUT_TCPWM1_TR_IN8
#define tcpwm_1_cnt_2_start_0_TRIGGER_OUT TRIG3_OUT_TCPWM1_TR_IN9

#define TCPWM1_CNT2_COUNT_VALUE 0xa
#define TCPWM1_CNT2_START_VALUE 0xb

#if defined(__cplusplus)
}
#endif


#endif /* CYCFG_ROUTING_H */
