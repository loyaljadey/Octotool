/******************************************************************************
* File Name:   main.c
*
* Description: This code example demonstrates the use of GPIO configured as an
*              input pin to generate interrupts in PSoC 6 MCU.
*
* Related Document: README.md
*
*******************************************************************************
* Copyright 2019-2021, Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
*
* This software, including source code, documentation and related
* materials ("Software") is owned by Cypress Semiconductor Corporation
* or one of its affiliates ("Cypress") and is protected by and subject to
* worldwide patent protection (United States and foreign),
* United States copyright laws and international treaty provisions.
* Therefore, you may use this Software only as provided in the license
* agreement accompanying the software package from which you
* obtained this Software ("EULA").
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software
* source code solely for use in connection with Cypress's
* integrated circuit products.  Any reproduction, modification, translation,
* compilation, or representation of this Software except as specified
* above is prohibited without the express written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer
* of such system or application assumes all risk of such use and in doing
* so agrees to indemnify Cypress against all liability.
*******************************************************************************/

#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"
#include "cy_retarget_io.h"
#include "math.h"
#include "stdlib.h"

/******************************************************************************
 * Macros
 *****************************************************************************/

#define GPIO_INTERRUPT_PRIORITY (6u)
#define GPIO_ECHO_PRIORITY      (7u)
#define GPIO_TRIGGER_PRIORITY   (7u)

#define DATA_SAMPLE_COUNT		(128u)

#define My_Square_Wave_HW TCPWM0
#define My_Square_Wave_NUM 1UL
#define My_Square_Wave_MASK (1UL << 1)
#define My_Square_Wave_INPUT_DISABLED 0x7U


/*******************************************************************************
* Function Prototypes
********************************************************************************/
static void gpio_interrupt_handler(void *handler_arg, cyhal_gpio_event_t event);
static void gpio_echo_handler(void *handler_arg, cyhal_gpio_event_t event);
static void pwm_trigger_handler(void);


/*******************************************************************************
* Global Variables
********************************************************************************/
volatile bool gpio_intr_flag = false;
bool ECHO1 = true;
bool ECHO2 = true;
bool ECHO1_DONE = false;
bool ECHO2_DONE = false;

volatile uint32_t Pulsewidth_ping[1024];
volatile uint32_t Pulsewidth_pong[1024];
volatile uint32_t Pulsewidth_Avg=0;
volatile uint32_t transmit_reading1 = 6789;
volatile uint32_t transmit_reading2 = 6789;
volatile uint16_t echo_index=0;

volatile uint32_t read_val=0;

volatile bool ping = 1;
volatile bool data_avail = 0;
volatile bool transmit_data = 0;

cyhal_timer_t timer_obj;
cyhal_timer_t timer_obj2;
cyhal_pwm_t Trigger;
void *callback_arg;

#define MY_TCPWM_PWM_NUM   (0UL)
#define MY_TCPWM_PWM_MASK  (1UL << 0)
#define MY_TCPWM_CNT_NUM   (1UL)
#define MY_TCPWM_CNT_MASK  (1UL << 1)
#define MOTOR_ENC_CNT   (408)
#define PWM_TO_SPD  (150/100)
#define K_p (80)
#define K_i (0.75)
#define MAX_ERROR (0.75)
#define UART_DELAY (5u)

volatile int counter1 = 0;
volatile int counter2 = 0;
volatile int spd1 = 0;
volatile int spd2 = 0;
volatile int desSpd1 = 0;
volatile int desSpd2 = 0;
volatile int PWM1 = 0;
volatile int PWM2 = 0;
volatile int error1 = 0;
volatile int error2 = 0;
volatile int accErr1 = 0;
volatile int accErr2 = 0;
int US1 = 0; //P5_6
int US2 = 0; //P6_2
int US3 = 0; //P6_3
int US4 = 0; //P6_4
int diffFront = 0;
int diffBack = 0;
int distanceF = 0;
int distanceB = 0;
int tolF = 2000;
int tolB = 2000;
int tolS = 8000;
int state = 0; /*0 is idle, 1 is sensing, 2 is F, 3 is B, 4 is R, 5 is L*/
int prevState = 0;
int dir1 = 0;// 0 is idle, 1 is forward, 2 is back
int dir2 = 0;
int desDist = 5000;
cyhal_pwm_t pwm1;
cy_rslt_t rslt;
cyhal_timer_t timer0;
cyhal_gpio_t ECHOPIN;
cyhal_gpio_t in1 = P10_0;
cyhal_gpio_t in2 = P10_1;
cyhal_gpio_t in3 = P10_2;
cyhal_gpio_t in4 = P10_3;
//cyhal_gpio_t us1 = P5_6;
//cyhal_gpio_t us2 = P5_5;
//cyhal_gpio_t us3 = P5_4;
//cyhal_gpio_t us4 = P5_3;
cyhal_quaddec_t dec1;
cyhal_quaddec_t dec2;
volatile uint32_t count1 = 0x8000, prev_count1 = 0x8000;
volatile uint32_t count2 = 0x8000, prev_count2 = 0x8000;
uint8_t uart_read_value;
uint8_t tx_buf[1];
size_t tx_length = 2;
size_t rx_length = 1;
int diff1 = 0;
int diff2 = 0;


//void setPWM(){
//    error1 = desSpd1 - spd1;
//    error2 = desSpd2 - spd2;
//    accErr1 += error1;
//    accErr2 += error2;
//    if (accErr1 > MAX_ERROR){
//        accErr1 = MAX_ERROR;
//    }
//    if (accErr2 > MAX_ERROR){
//        accErr2 = MAX_ERROR;
//    }
//    int temp1 = (error1 * K_p + accErr1 * K_i) * 1/((int)PWM_TO_SPD);
//    int temp2 = (error2 * K_p + accErr2 * K_i) * (int)32768 / (int)150;
//    if(temp1 > 100){
//    	PWM1 = 100;
//    }
//    else{
//    	PWM1 = temp1;
//    }
//    if(temp2 > 32768){
//    	PWM2 = 32768;
//    }
//    else{
//    	PWM2 = temp2;
//    }
//    cyhal_pwm_set_duty_cycle(&pwm1, PWM1, 1000);
//    Cy_TCPWM_PWM_SetCompare0(TCPWM1, MY_TCPWM_PWM_NUM, (uint32_t)PWM2);
//    Cy_TCPWM_PWM_SetCompare1(TCPWM1, MY_TCPWM_PWM_NUM, (uint32_t)PWM2);
//
//}

void getUS()
	{
		US1 = transmit_reading1;//cyhal_gpio_read(us1); placeholder
		US2 = transmit_reading2;//cyhal_gpio_read(us2);
		US3 = 7000;//cyhal_gpio_read(us3);
		US4 = 7000;//cyhal_gpio_read(us4);
		diffFront = US1 - US2;
		diffBack = 0;
		distanceF = (US1+US2)/2;
		//distanceB = US3;
	}

void isr_timer(void *callback_arg, cyhal_timer_event_t event)
	{
		switch(state)
			{
				case 1 : //sensing
					if(diffFront > tolS/* || diffBack < tol*/){state = 4;} else if(diffFront < -tolS/* || diffBack > tol*/){state = 5;}
					else if(abs(diffFront) <= tolS && distanceF >= (tolF+desDist)){state = 2;} else if(abs(diffBack) <=  tolS && distanceF <= (desDist-tolB)){state = 3;};
					break;
				case 4 : //left
					if(diffFront < -tolS/* || diffBack > tol*/){state = 5;} else if(abs(diffFront) <= tolS && distanceF >= (tolF+desDist)){state = 2;}
					else if((abs(diffFront) <= tolS /*|| abs(diffBack) <=  tol*/) && (distanceF <= (tolF+desDist) && distanceF >= (desDist - tolB) /*&& distanceB >= tol*/)){state = 1;}
					else if(abs(diffBack) <=  tolS && distanceF <= (desDist-tolB)){state = 3;};
					break;
				case 5 : //right
					if(diffFront > tolS/* || diffBack < tol*/){state = 4;} else if(abs(diffFront) <= tolS && distanceF >= tolF+desDist){state = 2;}
					else if((abs(diffFront) <= tolS /*|| abs(diffBack) <=  tol*/) && (distanceF <= (tolF+desDist) && distanceF >= (desDist - tolB) /*&& distanceB >= tol*/)){state = 1;}
					else if(abs(diffBack) <=  tolS && distanceF <= (desDist-tolB)){state = 3;};
					break;
				case 2 : //front
					if(diffFront > tolS/* || diffBack < tol*/){state = 4;} else if(diffFront < -tolS/* || diffBack > tol*/){state = 5;}
					else if((abs(diffFront) <= tolS /*|| abs(diffBack) <=  tol*/) && (distanceF <= (tolF+desDist) && distanceF >= (desDist - tolB)/*&& distanceB >= tol*/)){state = 1;}
					else if(abs(diffBack) <=  tolS && distanceF <= desDist-tolB){state = 3;};
					break;
				case 3 : //back
					if(diffFront > tolS/* || diffBack < tol*/){state = 4;} else if(diffFront < -tolS/* || diffBack > tol*/){state = 5;}
					else if((abs(diffFront) <= tolS /*|| abs(diffBack) <=  tol*/) && (distanceF <= (tolF+desDist) && distanceF >= (desDist - tolB) /*&& distanceB >= tol*/)){state = 1;}
					else if(abs(diffFront) <= tolS && distanceF >= tolF+desDist){state = 2;};
			}
	switch(state)
		{
	    	case(0) :
				desSpd1 = 0;
				desSpd2 = 0;
				//prevState = 0;
				tx_buf[0] = 'N';
				break;
	    	case(1) :
				desSpd1 = 0;
	    		desSpd2 = 0;
				//prevState = 1;
				//tx_buf[0] = 'O';
				printf("O\r\n");
	    		break;
	    	case(2) :
				cyhal_gpio_write(in1,true);
				cyhal_gpio_write(in2,false);
				cyhal_gpio_write(in3,true);
				cyhal_gpio_write(in4,false);
				desSpd1 = 50;
			    desSpd2 = 50;
				//prevState = 2;
				//tx_buf[0] = 'F';
				printf("F\r\n");
			    break;
	    	case(3) :
				cyhal_gpio_write(in1,false);
				cyhal_gpio_write(in2,true);
				cyhal_gpio_write(in3,false);
				cyhal_gpio_write(in4,true);
				desSpd1 = 10;
			    desSpd2 = 10;
				//prevState = 3;
				//tx_buf[0] = 'B';
				printf("B\r\n");
			    break;
	    	case(4) :
				cyhal_gpio_write(in1,true);
				cyhal_gpio_write(in2,false);
				cyhal_gpio_write(in3,false);
				cyhal_gpio_write(in4,false);
				desSpd1 = 50;
				desSpd2 = 0;
				//prevState = 4;
				//tx_buf[0] = 'L';
				printf("L\r\n");
				break;
	    	case(5) :
				cyhal_gpio_write(in1,false);
				cyhal_gpio_write(in2,false);
				cyhal_gpio_write(in3,true);
				cyhal_gpio_write(in4,false);
				desSpd1 = 0;
				desSpd2 = 50;
				//prevState = 5;
				//tx_buf[0] = 'R';
				printf("R\r\n");
				break;
		}

	//	if(state != prevState){
	//		cyhal_uart_write(&cy_retarget_io_uart_obj, (void*)tx_buf, &tx_length);
	//		cyhal_uart_putc(&cy_retarget_io_uart_obj,tx_buf[0]);
	//	}
		prev_count1 = count1;
		prev_count2 = count2;
		diff1 = abs(count1 - prev_count1);
		diff2 = abs(count2 - prev_count2);
		spd1 = diff1/MOTOR_ENC_CNT * 50;
		spd2 = diff2/MOTOR_ENC_CNT * 50;
		error1 = desSpd1 - spd1;
		error2 = desSpd2 - spd2;
		accErr1 += error1;
		accErr2 += error2;
		if (accErr1 > MAX_ERROR){
			accErr1 = MAX_ERROR;
		}
		if (accErr2 > MAX_ERROR){
			accErr2 = MAX_ERROR;
		}
		int temp1 = (error1 * K_p + accErr1 * K_i) * 1/((int)PWM_TO_SPD);
		int temp2 = (error2 * K_p + accErr2 * K_i) * (int)32768 / (int)150;
		if(temp1 > 100){
			PWM1 = 100;
		}
		else{
			PWM1 = temp1;
		}
		if(temp2 > 32768){
			PWM2 = 32768;
		}
		else{
			PWM2 = temp2;
		}
		cyhal_pwm_set_duty_cycle(&pwm1, PWM1, 1000);
		Cy_TCPWM_PWM_SetCompare0(TCPWM1, MY_TCPWM_PWM_NUM, (uint32_t)PWM2);
		Cy_TCPWM_PWM_SetCompare1(TCPWM1, MY_TCPWM_PWM_NUM, (uint32_t)PWM2);

		//printf("%d\n\r",count1);
		//printf("%d\n\r",diff2);
	}


const cyhal_timer_cfg_t timer_cfg =
	{
	 .compare_value = 0,                  // Timer compare value, not used
	 .period        = 2000000,              // Timer period set to a large enough value
										  //   compared to event being measured
	 .direction     = CYHAL_TIMER_DIR_UP, // Timer counts up
	 .is_compare    = false,              // Don't use compare mode
	 .is_continuous = false,              // Do not run timer indefinitely
	 .value         = 0                   // Initial value of counter
	};

cy_stc_sysint_t Isr_Trigger_config =
	{
	 .intrSrc = (IRQn_Type) My_Trigger_Pulse_IRQ,
	 .intrPriority = 7u
	};



/*******************************************************************************
* Function Name: main
********************************************************************************
* Summary:
*  System entrance point. This function configures and initializes the GPIO
*  interrupt, update the delay on every GPIO interrupt, blinks the LED and enter
*  in deepsleep mode.
*
* Return: int
*
*******************************************************************************/
int main(void)
{
    cy_rslt_t result;

    uint16_t i;

    /* Initialize the device and board peripherals */
    result = cybsp_init();
    /* Board init failed. Stop program execution */
    if (result != CY_RSLT_SUCCESS)
    {
        CY_ASSERT(0);
    }
    /* Initialize retarget-io to use the debug UART port */
    result = cy_retarget_io_init(CYBSP_DEBUG_UART_TX, CYBSP_DEBUG_UART_RX,
                                 CY_RETARGET_IO_BAUDRATE);

    /***************************************************************************************************/
    /*																								   */
    /*	Setting up GPIO to drive the on-board LED (P13.7)											   */
    /*																								   */
    /***************************************************************************************************/
    /* Initialize the user LED */
    result = cyhal_gpio_init(CYBSP_USER_LED, CYHAL_GPIO_DIR_OUTPUT,
                    CYHAL_GPIO_DRIVE_STRONG, CYBSP_LED_STATE_OFF);

    /***************************************************************************************************/
    /*																								   */
    /*	Setting up GPIO for the button as input and its interrupt handler							   */
    /*																								   */
    /***************************************************************************************************/
    /* Initialize the user button */
    result = cyhal_gpio_init(CYBSP_USER_BTN, CYHAL_GPIO_DIR_INPUT,
                    CYHAL_GPIO_DRIVE_PULLUP, CYBSP_BTN_OFF);
    /* Configure GPIO interrupt */
    cyhal_gpio_register_callback(CYBSP_USER_BTN, (cyhal_gpio_event_callback_t) gpio_interrupt_handler, NULL);
    cyhal_gpio_enable_event(CYBSP_USER_BTN, CYHAL_GPIO_IRQ_FALL, 
                                 GPIO_INTERRUPT_PRIORITY, true);


    /***************************************************************************************************/
    /*																								   */
    /*	Setting up an echo pin for an ultrasonic sensor											       */
    /*																								   */
    /***************************************************************************************************/
    /* Setting up the reading of the echo pin via interrupts */
    result = cyhal_gpio_init(MY_ECHO_PIN,CYHAL_GPIO_DIR_INPUT,
                    CYHAL_GPIO_DRIVE_NONE, CYBSP_BTN_OFF);
    /* Setup the interrupt handler for the echo signal */
    cyhal_gpio_register_callback(MY_ECHO_PIN,
                                     gpio_echo_handler, NULL);
    /* Setup the interrupt for both rising and falling of the echo signal */
    cyhal_gpio_enable_event(MY_ECHO_PIN, CYHAL_GPIO_IRQ_BOTH,
                                     GPIO_ECHO_PRIORITY, ECHO1);


	/***************************************************************************************************/
	/*																								   */
	/*	Setting up a sceond echo pin for an ultrasonic sensor											       */
	/*																								   */
	/***************************************************************************************************/
	/* Setting up the reading of the echo pin via interrupts */
	result = cyhal_gpio_init(MY_ECHO_PIN_2,CYHAL_GPIO_DIR_INPUT,
					CYHAL_GPIO_DRIVE_NONE, CYBSP_BTN_OFF);
	/* Setup the interrupt handler for the echo signal */
	cyhal_gpio_register_callback(MY_ECHO_PIN_2,
									 gpio_echo_handler, NULL);

	/***************************************************************************************************/
	/*																								   */
	/*	Setting timer1 so we can measure width of echo pin1   										   */
	/*																								   */
	/***************************************************************************************************/
	// Initialize the timer object. Does not use pin output ('pin' is NC) and does not use a
	// pre-configured clock source ('clk' is NULL).
	cyhal_timer_init(&timer_obj, NC, NULL);
	// Apply timer configuration such as period, count direction, run mode, etc.
	cyhal_timer_configure(&timer_obj, &timer_cfg);
	// Set the frequency of timer to 10000 counts in a second or 10000 Hz
	cyhal_timer_set_frequency(&timer_obj, 5000000);

	/***************************************************************************************************/
	/*																								 */
	/*	Setting up PWM to generate the trigger at 30 ms period and 12 us pulsewidth.				 */
	/*	The timing values are configured with Device Configurator based on a 25 Mhz Clock			 */
	/*																								 */
	/***************************************************************************************************/
	Cy_TCPWM_PWM_Init (TCPWM0, My_Trigger_Pulse_NUM, &My_Trigger_Pulse_config);

	Cy_TCPWM_PWM_Enable(TCPWM0,My_Trigger_Pulse_NUM);

	Cy_TCPWM_SetInterruptMask(TCPWM0, My_Trigger_Pulse_NUM,CY_TCPWM_INT_ON_TC);


	/* Configure the ISR for the TCPWM peripheral*/
	Cy_SysInt_Init(&Isr_Trigger_config, pwm_trigger_handler);
	/* Enable interrupt in NVIC */
	NVIC_EnableIRQ((IRQn_Type)Isr_Trigger_config.intrSrc);

	Cy_TCPWM_TriggerStart_Single(TCPWM0, My_Trigger_Pulse_NUM);


	/* Enable global interrupts */
	__enable_irq();

	/* \x1b[2J\x1b[;H - ANSI ESC sequence for clear screen */
	printf("\x1b[2J\x1b[;H");
	printf("**************** PSoC 6 MCU: GPIO Interrupt *****************\r\n");

	printf("Measuring Echo Width\r\n");


	/*initializing the gpio pin for the irsensor*/
	result = cyhal_gpio_init(P10_6,CYHAL_GPIO_DIR_INPUT,CYHAL_GPIO_DRIVE_NONE, CYBSP_BTN_OFF);

	/*setting up a local variable for the boolean ouput of irsensor*/
	//bool IR_output;



	//motor code

	//Init the motor direction pins
	cyhal_gpio_init(in1,CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, false);
	cyhal_gpio_init(in2,CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, false);
	cyhal_gpio_init(in3,CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, false);
	cyhal_gpio_init(in4,CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, false);

	//decoder2 PDL

	Cy_TCPWM_QuadDec_Init(TCPWM1, 2UL, &tcpwm_1_cnt_2_config);

	Cy_TCPWM_QuadDec_Enable(TCPWM1, 2UL);

	Cy_TCPWM_TriggerStart(TCPWM1, (1UL << 2));

	//decoder1 HAL

	cyhal_quaddec_init(&dec1, P9_0, P9_1, NC, CYHAL_QUADDEC_RESOLUTION_1X, NULL,
									  1000000);//Ask Professor
	cyhal_quaddec_start(&dec1);

	//PWM1 HAL

	cyhal_pwm_init(&pwm1,P5_2, NULL);//HAL
	cyhal_pwm_set_duty_cycle(&pwm1, 10, 1000000);
	cyhal_pwm_start(&pwm1);

	//PWM2 PDL

	Cy_TCPWM_PWM_Init(TCPWM1, MY_TCPWM_PWM_NUM, &tcpwm_1_cnt_0_config);

	Cy_TCPWM_PWM_Enable(TCPWM1, MY_TCPWM_PWM_NUM);

	Cy_TCPWM_TriggerStart(TCPWM1,MY_TCPWM_PWM_MASK);


	//timer interrupt
	const cyhal_timer_cfg_t timer_cfg =
	{
		.compare_value = 0,                 /* Timer compare value, not used */
		.period = 200,                      /* Defines the timer period, stock is 20*/
		.direction = CYHAL_TIMER_DIR_UP,    /* Timer counts up */
		.is_compare = false,                /* Don't use compare mode */
		.is_continuous = true,              /* Run the timer indefinitely */
		.value = 0                          /* Initial value of counter */
	};
	cyhal_timer_init(&timer0, NC, NULL);
	cyhal_timer_configure(&timer0, &timer_cfg);
	cyhal_timer_set_frequency(&timer0, 10000);
	cyhal_timer_register_callback(&timer0, isr_timer, NULL);
	cyhal_timer_enable_event(&timer0, CYHAL_TIMER_IRQ_TERMINAL_COUNT, 1, true);
	cyhal_timer_start(&timer0);




	for(;;) {
		//IR_output = cyhal_gpio_read(P12_7);
		//printf("%s", IR_output ? "true\n" : "false\n");
//		if(IR_output == true) {
//			printf("No detection\r\n\n");
//		}
//		else {
//			printf("Object close\r\n\n");
//
//		}


		/* Check the interrupt status */


		count1 = cyhal_quaddec_read_counter(&dec1);
		count2 = Cy_TCPWM_QuadDec_GetCounter(TCPWM1, MY_TCPWM_CNT_NUM);
		if(data_avail)
		{

			for(i=0;i<DATA_SAMPLE_COUNT;i++)
			{
				if(!ping)
				{
					Pulsewidth_Avg = Pulsewidth_Avg + Pulsewidth_pong[i];
				}
				else
				{
					Pulsewidth_Avg = Pulsewidth_Avg + Pulsewidth_ping[i];
				}

			}
			//printf("%ld\r\n", Pulsewidth_Avg/DATA_SAMPLE_COUNT);
			data_avail = 0;
		}


		//switch the interrupt for the ultrasonic sensors on and off by switching the state at the end of the cyhal_gpio_enable_event method
		if(ECHO1_DONE){
			cyhal_gpio_enable_event(MY_ECHO_PIN, CYHAL_GPIO_IRQ_BOTH,
												 GPIO_ECHO_PRIORITY, false);
			cyhal_gpio_enable_event(MY_ECHO_PIN_2, CYHAL_GPIO_IRQ_BOTH,
												 GPIO_ECHO_PRIORITY, true);
			ECHO1_DONE = false;
		}
		if(ECHO2_DONE){
			cyhal_gpio_enable_event(MY_ECHO_PIN_2, CYHAL_GPIO_IRQ_BOTH,
												 GPIO_ECHO_PRIORITY, false);
			cyhal_gpio_enable_event(MY_ECHO_PIN, CYHAL_GPIO_IRQ_BOTH,
												 GPIO_ECHO_PRIORITY, true);
			ECHO2_DONE = false;
		}


		//setPWM();
		//this gets the ultrasonic readings
		getUS();

		//cyhal_uart_read(&cy_retarget_io_uart_obj, (void*)rx_buf, &rx_length);
		cyhal_uart_getc(&cy_retarget_io_uart_obj, &uart_read_value, 1);
		switch(uart_read_value){
			case 'I':
				printf("IPSOC\r\n");
				break;
			case 'T':
				state = 1;
				break;
			case 'S':
				if (state == 0) {
					state = 1;
				}
				else {
					state = 0;
				}
				break;
			default:
				break;
		}
//		if(ECHOPIN == MY_ECHO_PIN){
//			 printf("PIN1\n\r");
//		 }
//		 else{
//			 printf("PIN2\n\r");
//		 }
//		printf("Transmit reading ultra1\n\r");
//		 printf("%d\n\r", transmit_reading1);
//		 printf("Transmit reading ultra2\n\r");
//		 printf("%d\n\r", transmit_reading2);
	}
}


/*******************************************************************************
* Function Name: gpio_interrupt_handler
********************************************************************************
* Summary:
*   GPIO interrupt handler.
*
* Parameters:
*  void *handler_arg (unused)
*  cyhal_gpio_irq_event_t (unused)
*
*******************************************************************************/
static void gpio_interrupt_handler(void *handler_arg, cyhal_gpio_irq_event_t event)
{
    gpio_intr_flag = true;
}

static void gpio_echo_handler(void *handler_arg, cyhal_gpio_irq_event_t event)
{
	bool My_echo_pin_value1;

	if((My_echo_pin_value1=cyhal_gpio_read(ECHOPIN)))
	{
		cyhal_timer_start(&timer_obj);
	}
	else
	{
		cyhal_timer_stop(&timer_obj);
		if(ECHOPIN == MY_ECHO_PIN){
			transmit_reading1 = cyhal_timer_read(&timer_obj);
		}
		else{

			transmit_reading2 = cyhal_timer_read(&timer_obj);
		}
		transmit_data = 1;
		if(ping && ECHOPIN == MY_ECHO_PIN)
		{
			Pulsewidth_ping[(echo_index)] = transmit_reading1;
		}
		else if(ECHOPIN == MY_ECHO_PIN)
		{
			Pulsewidth_pong[(echo_index)] = transmit_reading1;
		}
		else if(ping && ECHOPIN == MY_ECHO_PIN_2){
			Pulsewidth_ping[(echo_index)] = transmit_reading2;
		}
		else{
			Pulsewidth_pong[(echo_index)] = transmit_reading2;
		}
		cyhal_timer_reset(&timer_obj);
		if(ECHOPIN == MY_ECHO_PIN){
			ECHOPIN = MY_ECHO_PIN_2;
			ECHO1_DONE = true;
		}
		else{
			ECHOPIN = MY_ECHO_PIN;
			ECHO2_DONE = true;
		}
		echo_index = (echo_index+1)%DATA_SAMPLE_COUNT;
		if(echo_index == 0)
		{
			ping = ping^1;
			Pulsewidth_Avg=0;
			data_avail = 1;
		}
	}
}

static void pwm_trigger_handler(void)
{
	 /* Clear the TCPWM peripheral interrupt */
	 Cy_TCPWM_ClearInterrupt(My_Trigger_Pulse_HW, My_Trigger_Pulse_NUM, CY_TCPWM_INT_ON_TC);
	 /* Clear the CM4 NVIC pending interrupt for TCPWM */
	 NVIC_ClearPendingIRQ(Isr_Trigger_config.intrSrc);

	 if(transmit_data)
	 {
//		 printf("Transmit reading ultra1\n\r");
//		 printf("%d\n\r", transmit_reading1);
//		 printf("Transmit reading ultra2\n\r");
//		 printf("%d\n\r", transmit_reading2);
//		 printf("PWM1\n\r");
//		 printf("%d\n\r",PWM1);
//		 printf("PWM2\n\r");
//		 printf("%d\n\r\n",PWM2);

		 transmit_data = 0;
	 }
}


/* [] END OF FILE */
